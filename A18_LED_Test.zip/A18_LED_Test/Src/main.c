#include "stm32f4xx.h"

void TIM2_Configuration(void);
void GPIO_Configuration(void);

int main(void) {
    // Configure GPIO
    GPIO_Configuration();

    // Configure Timer 2
    TIM2_Configuration();

    while (1) {
        // Main loop, the LED toggling is handled by the timer interrupt
    }
}

void TIM2_Configuration(void) {
    // Enable Timer 2 clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    // Set prescaler value to 8399, so the timer frequency is 84 MHz / (8399 + 1) = 10 kHz
    TIM2->PSC = 8399;

    // Set auto-reload register to generate an interrupt every 500 ms (10 kHz / 500 = 20000)
    TIM2->ARR = 20000 - 1;

    // Enable timer update interrupt
    TIM2->DIER |= TIM_DIER_UIE;

    // Enable Timer 2
    TIM2->CR1 |= TIM_CR1_CEN;

    // Enable TIM2_IRQn interrupt
    NVIC_EnableIRQ(TIM2_IRQn);
}

void GPIO_Configuration(void) {
    // Enable GPIO D clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;

    // Configure PD12 (LED) as output
    GPIOD->MODER |= GPIO_MODER_MODER12_0;
}

// Timer 2 interrupt handler
void TIM2_IRQHandler(void) {
    // Clear the interrupt flag
    TIM2->SR &= ~TIM_SR_UIF;

    // Toggle the LED (PD12)
    GPIOD->ODR ^= GPIO_ODR_ODR_12;
}
