#include <stdint.h>
#include "stm32f4xx_hal.h" // Include the HAL library for STM32F4 series (adjust based on your specific STM32 MCU)

TIM_HandleTypeDef htim2;

// Function prototypes
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

int main(void)
{
    // Initialize HAL library
    HAL_Init();

    // Configure the system clock
    SystemClock_Config();

    // Initialize peripherals
    MX_GPIO_Init();
    MX_TIM2_Init();

    // Start the timer
    HAL_TIM_Base_Start_IT(&htim2);

    while (1)
    {
        // Your main application code here
    }
}

// Timer initialization function
void MX_TIM2_Init(void)
{
    // Enable the peripheral clock for TIM2
    __HAL_RCC_TIM2_CLK_ENABLE();

    // Configure TIM2
    htim2.Instance = TIM2;
    htim2.Init.Prescaler = 8399; // Assuming a 84 MHz clock, 1000 Hz timer frequency
    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim2.Init.Period = 99; // 1000 Hz frequency
    htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    HAL_TIM_Base_Init(&htim2);
}

// GPIO initialization function
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Enable the peripheral clock for GPIOD
    __HAL_RCC_GPI
